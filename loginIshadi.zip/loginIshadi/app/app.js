/**
 * Created by DELL on 7/1/2017.
 */

var myApp = angular.module('myApp', ['ngRoute','myApp.controller','ngStorage']);


myApp.config(['$routeProvider',function ($routeProvider) {
    $routeProvider.when('/',{
    templateUrl:'view/login.html',
        controller:'Logincontroller'
}).when('/home',{
        resolve:{
            'check':function ($location,$localStorage) {
                if(!$localStorage.loggedIn)
                {
                    $location.path('/');
                }else{
                    console.log('Else');
                }
            }
        },
        templateUrl:'view/home.html'
    });
}]);

angular.module('myApp.controller',[])
    .controller('Logincontroller'['$scope','$location','$localStorage',function ($scope,$localStorage,$location) {
        $scope.submitLogin=function () {
            $localStorage.loggedIn=false;
            console.log('Submit');
            if(($scope.username='admin')&&( $scope.password='admin'))
            {
                $localStorage.loggedIn=true;
                console.log('success');
                $location('/home');
            }else{
                $scope.errorLogin='Enter valid user name and a password';
            }
        };
    }]);

/*
myApp.config('LabController', ['$scope', '$http', function($scope, $http) {
    getLab();
    function getLab() {
        $http.get('/LabTests/').then(response => {
            $scope.Tests = response.data;
        $scope.Test = null;
    });
    };
*/